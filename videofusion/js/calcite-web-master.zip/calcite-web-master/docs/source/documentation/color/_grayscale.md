Calcite Web mostly deals with large-field layouts and a broader range of visual communication, including small interfaces and long format reading. With this in mind, Calcite Web's grayscale differs from that of Calcite Desktop.

Calcite web provides a short list of simple color variables, while supporting the complete set of official calcite colors.
