
Calcite Web's interface icon set is available both as an icon font and as inline SVG files.

If you're using the icon font, just add the class `icon-ui-{name}` to an element. If you're using inline SVG, just copy and paste the SVG code into your project.

Icons have padding built into them so they can sit alongside text, to remove this padding, use the `icon-ui-flush` class.