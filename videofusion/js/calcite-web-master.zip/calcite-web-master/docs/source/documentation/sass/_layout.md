Calcite web has several mixins to help add space to your designs. Read on to learn how you can use mixins apply margin and padding to each side of an element.
