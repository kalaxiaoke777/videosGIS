Tracking is the space between letters in a word. The `tracking($n)` mixin accepts an integer, and applies letterspacing to the element as fractions of 1/1000 of an em.
`@include tracking(500)` will apply 1/2 em letterspacing.
`@include tracking(166)` will apply a hairline em letterspacing.
