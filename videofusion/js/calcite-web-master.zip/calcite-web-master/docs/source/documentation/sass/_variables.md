Calcite Web comes with several variables. These variables represent project-standard configurations of different aspects. For example, `$baseline` can be used in your Sass to set a property to the default typographic baseline of Calcite Web.

These variables can also be configured in your own project to change the library for project-specific applications.

Below are all of the variables and a brief description of what they represent.
