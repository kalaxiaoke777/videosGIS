The `text-right` and `text-left` mixins are useful to set text alignment. These mixins will automatically reverse in right to left languages.

```scss
@include text-right();
@include text-left();
```
