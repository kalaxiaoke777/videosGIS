The modifier class `inline-block` will add `display: inline-block` to an element.
