JavaScript dependent helper classes that surface simple class-based hooks for common interactive layout patterns.
