Alerts are used to inform users of state changes, errors, or successful actions. Alerts are only visible if they have the `is-active` class. Without as `is-active` class, the alert will be set to `display: none;`

Calcite does not manage alert classes by default - you will have to write your own JavaScript handlers for this.
