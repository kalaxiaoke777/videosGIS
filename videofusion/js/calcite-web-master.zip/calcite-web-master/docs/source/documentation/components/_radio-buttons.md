Much like checkboxes, radio buttons are largely left alone except for alterations in spacing and focus state.
