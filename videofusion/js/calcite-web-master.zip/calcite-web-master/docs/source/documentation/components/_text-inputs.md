Text inputs should be placed inside a `label` element. See the [form validation](#form-validation) for a more complete `input-error` example.

