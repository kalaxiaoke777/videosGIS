Animation helper classes are used to provide character, visual richness, and tactile feedback for the user. Adding an `.animate-` class to any DOM node will animate that node. Using JavaScript to add `.animate-fade-in` to a DOM node when it enters the viewport will cause that node to fade in.

<button class="btn js-replay-animations">Replay Animations</button>
