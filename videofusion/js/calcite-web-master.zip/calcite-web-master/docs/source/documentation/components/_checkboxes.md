Checkboxes are aligned properly and given a focus state consistent with other form elements. Other than that they are left as is.
