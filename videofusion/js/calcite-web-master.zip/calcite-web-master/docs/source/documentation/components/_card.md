Cards are like panels, but a little more structured. They can have titles, buttons, and full bleed images. Use cards when panels are too simple.

If you don't have an image, use the `.card-bar-blue` (or another color) to add some graphic punch.