The radio group component provides an additional style with more visual prominence than a plain `select` or `radio`.

It is structured as a typical radio input for accessibility.
