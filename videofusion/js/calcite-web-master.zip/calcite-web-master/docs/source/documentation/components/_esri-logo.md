A minimum buffer zone of clear space is maintained around the logo. Display of the logo should not be less than 78 x 28 pixels. This minimun size and buffer is part of the component, designed to be as simple to use as possible.

Use of the reverse logo should only be on top of dark backgrounds. Neither logo should be used on top of images, or altered in any way.
