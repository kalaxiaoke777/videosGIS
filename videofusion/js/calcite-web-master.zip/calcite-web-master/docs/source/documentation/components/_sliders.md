This is a simple range slider input component to provide consistent cross-browser styles. In the future we hope to add more functionality via opt-in js classes.
