Action bars are used to display multiple actions horizontally. Actions are meant to be used with buttons. They are clearfixed and floated right by default.
