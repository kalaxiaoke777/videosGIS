Designed to be combined with the [user sign in pattern](#user-sign-in) pattern on sites where a logged in portion is accessible.
