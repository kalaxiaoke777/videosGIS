The loader element is a placeholder while content is being retrieved or rendered. By default, the loader is set to `display: none;` and requires an `is-active` class to display.
