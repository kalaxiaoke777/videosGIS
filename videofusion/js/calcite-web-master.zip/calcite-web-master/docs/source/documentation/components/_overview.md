Components are reusable blocks that can be used across any part of a Calcite site. They can be used within [patterns](../patterns/) or on their own.
