Tooltips use an `aria-label` attribute to provide contextual help on hover. Tooltips can apply to any element.
