It is very common to have an input and a button attached to one another. The `input-group` component allows you to accomplish this with three classes.
