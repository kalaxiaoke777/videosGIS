The `js-accordion` class provides the JavaScript binding for the accordion pattern, which handles which pane of the accordion is active via the `is-active` class.

**Note:** Accordions have recently moved to using inline svg icons. If you're still using the icon font, simply set `$include-svg-icon` to `false` and omit the `accordion-icon` element.
