Use the pagination pattern to navigate between pages of displayed content, either in a gallery or a search result view.
