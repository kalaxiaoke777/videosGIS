The search pattern is a a UI for site-wide searches. The most regular use of the pattern is in the Top Navigation pattern.
