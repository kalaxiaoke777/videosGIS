Sidebar can be used either for in-page navigation — like on this page — or for lists of articles under a given topic.
