The framework includes a quick set of styles for a tabbed interface pattern. The full tab container will expand to fit its parent.

As an added bonus, this component supports intelligently restricting the width of tabs if they get too long and numerous.

`tabs-gray` can be used to display code samples. Just wrap code blocks in `<pre>` and `<code>` tags inside the element with `.tab-section` class.
