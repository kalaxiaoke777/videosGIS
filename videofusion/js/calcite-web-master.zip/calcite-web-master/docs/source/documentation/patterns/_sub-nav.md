The 'Sub-Nav' provides a second level of hierarchy to a site. While the top-nav includes the top-most level of navigation, the sub-nav includes navigation for sections nested inside that. The subnav has a tabbed navigation pattern, a title, and room for a call to action.

You can also turn the sub-nav into a more graphically-driven banner by adding `padding-leader` and `padding-trailer` classes to the title, thereby increasing the vertical size of the sub-nav.
