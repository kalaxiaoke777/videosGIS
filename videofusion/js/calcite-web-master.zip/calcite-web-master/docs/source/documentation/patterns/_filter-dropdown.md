The filter dropdown is a component used to select any number of items from a list of any number of options. It's used to locate specific items quickly even if that item is buried in a huge pile of other things.

The primary use cases for the filter dropdown are selecting tags from a tag cloud, or a group from a list of all a user's groups.

If the relationship being established is many-to-many, use the filter dropdown component.