Interactive patterns rely on `calcite-web.js` to work properly. You must add a reference to `calcite-web.js` (either from the cdn or you can host it yourself). After that, you should startup all the interactive patterns on load with `calcite.init()`.

For more on using `calcite-web.js` you can view the [JavaScript Documentation](../javascript/).