Designed to be combined with the [user sign in pattern](#user-nav) pattern on sites where a logged in portion is accessible.

The user navigation element is just a [dropdown](../components/#dropdowns) with a few special styles.
