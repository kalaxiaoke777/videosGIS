>Note: this component requires `calcite-web.js`. See [JavaScript](../javascript/) for a guide on using the JavaScript library with interactive patterns and components.

Click dropdowns provide a way to obscure complexity in navigation while keeping everything available. Clicking the link will open a menu revealing more options.
