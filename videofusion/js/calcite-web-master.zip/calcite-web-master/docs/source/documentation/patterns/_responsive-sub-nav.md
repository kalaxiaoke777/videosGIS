When a sub nav has more than two or three items in it, it may need to collapse down into a smaller space on smaller screen sizes. The following pattern will work within an app, with `tablet-show` or `phone-show` used as needed.

