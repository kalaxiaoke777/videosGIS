Build in classes that allow for quick customization and composition for a wide range of use cases.
