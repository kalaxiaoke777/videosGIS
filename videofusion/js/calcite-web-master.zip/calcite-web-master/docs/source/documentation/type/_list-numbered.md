Adds the Calcite styles for large numbered lists to an ordered list. Useful for listing steps in a process.
