All default text elements are styled to facilitate smooth reading, simple flow, and appropriate proportions. This is a default paragraph. This is a default [link](#). Below is a sample of default type elements.

# Header One
## Header Two
### Header Three
#### Header Four
##### Header Five
###### Header Six

00. List One that is really long and will break to the next line, demonstrating that the left edges of the text are aligned.
00. List Two
00. List Three

- List Item that is really long and will break to the next line, demonstrating that the left edges of the text are aligned.
  - sub list item
  - sub list item
- List Item
- List Item

> Lorem Ipsum Blockquote

Lorem ipsum paragraph with **strong, bold text** and _emphasis, italic text._

<dl>
	<dt>Guildenstern</dt>
	<dd>I don't believe in it anyway.</dd>
	<dt>Rosencrantz</dt>
	<dd>What?</dd>
	<dt>Guildenstern</dt>
	<dd>England.</dd>
	<dt>Rosencrantz</dt>
	<dd>Just a conspiracy of cartographers, then?</dd>
</dl>
