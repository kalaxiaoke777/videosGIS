Sets the font color of the element to any of the [Calcite colors](../color) available.
