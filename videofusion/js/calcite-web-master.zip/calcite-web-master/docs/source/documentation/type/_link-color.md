Sets the color of links within the element, or the link itself, to available [Calcite colors.](../color)
