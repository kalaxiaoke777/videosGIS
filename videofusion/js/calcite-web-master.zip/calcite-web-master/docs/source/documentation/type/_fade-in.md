On page load, applies an animation which transitions from `opacity: 0` to `opacity: 1`. Several compelling page load effects can be achieved with this class in conjunction with `transition-delay`.
