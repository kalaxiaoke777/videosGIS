Helpers classes apply the `font-size($n)` [mixin](../sass/#font-size) to an element. This allows for quick resizing of text elements up and down the [modular type size scale](../sass/#modular-scale).
