[Avenir Next](http://www.fonts.com/font/linotype/avenir-next) is a recut of the classic Avenir typeface, by Adrian Frutiger and Akira Kobayashi. It has been reworked for use on the web, and contains more weights, styles, and other improvements. Avenir Next improves on Avenir in web-specific settings.

Applies the the header face, along with a set of smart weight interactions and typographic defaults, to an element.

### Avenir Next

<h2 class="type-sample"> Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz</h2>

Several modifier classes are provided for quickly selecting different weights of Avenir Next. Weights range from light (default) to bold.

