var Clipboard;
var clipboard = new Clipboard('.js-copy-to-clipboard');
clipboard;
