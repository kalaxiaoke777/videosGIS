(function () {
  calcite.extend(calciteMarketing);
  calcite.init();
})();
